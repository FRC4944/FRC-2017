package org.usfirst.frc.team4944.robot.configurations;

public enum BotType {
	COMPETITION, PRACTICE
}